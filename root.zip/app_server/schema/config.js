//全局配置文件
module.exports = {
    //加密和解密token的密钥
    jwtSecretKey: 'ggw_web_homework',
    //token有效期
    expiresIn: '24h',
}